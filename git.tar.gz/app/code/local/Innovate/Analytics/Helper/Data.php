<?php

  class Innovate_Analytics_Helper_Data extends Mage_Core_Helper_Abstract
  {
  }
  
  